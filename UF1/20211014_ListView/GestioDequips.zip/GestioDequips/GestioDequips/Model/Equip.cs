﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestioDequips.Model
{
    public class Equip
    {
        private long id;
        private string nom;
        private string urlLogo;
        private string desc;
        private DateTime dataCreacio;

        OC<Jugador> jugador = new OC<Jugador>();
        Persona coach;

        public Equip(long id, string nom, string urlLogo, string desc, DateTime dataCreacio)
        {
            Id = id;
            Nom = nom;
            UrlLogo = urlLogo;
            Desc = desc;
            DataCreacio = dataCreacio;
        }

        public long Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string UrlLogo { get => urlLogo; set => urlLogo = value; }
        public string Desc { get => desc; set => desc = value; }
        public DateTime DataCreacio { get => dataCreacio; set => dataCreacio = value; }
        public OC<Jugador> Jugador { get => jugador; set => jugador = value; }
        public Persona Coach { get => coach; set => coach = value; }

        private static OC<Equip> llistaEquips;

        public Boolean Add(Jugador nouJugador)
        {
            if (this.Jugador.Contains(nouJugador))
            {
                return false;
            }

            this.Jugador.Add(nouJugador);

            return true;
        }

        public static OC<Equip> getLlistaEquips()
        {
            if(llistaEquips == null)
            {
                llistaEquips = new OC<Equip>();

                Equip e1 = new Equip(1, "Timberwolves", "https://a.espncdn.com/combiner/i?img=/i/teamlogos/nba/500/min.png", "", DateTime.Now);
                e1.Add(new Jugador(1,"D'Angelo", "Rusell", "USA", "https://ak-static.cms.nba.com/wp-content/uploads/headshots/nba/latest/260x190/1626156.png%22)", 22));
                e1.Add(new Jugador(2, "Manolo", "Fernan", "ESP", "https://ak-static.cms.nba.com/wp-content/uploads/headshots/nba/latest/260x190/1626156.png%22)", 42));
                e1.Add(new Jugador(3, "Paco", "Garcia", "ESP", "https://ak-static.cms.nba.com/wp-content/uploads/headshots/nba/latest/260x190/1626156.png%22)", 25));

                e1.coach = new Persona(2, "Chris", "Finch", "USA", "https://chorus.stimg.co/22321661/08_1012324552_Finch1216.jpg");

                llistaEquips.Add(e1);

                Equip e2 = new Equip(3, "Sant Antonio Spurs", "https://upload.wikimedia.org/wikipedia/en/thumb/a/a2/San_Antonio_Spurs.svg/1200px-San_Antonio_Spurs.svg.png", "", DateTime.Now);
                e2.Add(new Jugador(10, "D'Angelo", "Rusell", "USA", "https://ak-static.cms.nba.com/wp-content/uploads/headshots/nba/latest/260x190/1626156.png%22)", 22));
                e2.Add(new Jugador(20, "Manolo", "Fernan", "ESP", "https://ak-static.cms.nba.com/wp-content/uploads/headshots/nba/latest/260x190/1626156.png%22)", 42));
                e2.Add(new Jugador(30, "Paco", "Garcia", "ESP", "https://ak-static.cms.nba.com/wp-content/uploads/headshots/nba/latest/260x190/1626156.png%22)", 25));

                e2.coach = new Persona(2, "Greg", "Popvich", "USA", "https://www.nba.com/resources/static/team/v2/spurs/Schad/img/Spurs/Coaches/Pop.png");

                llistaEquips.Add(e2);
            }
            return llistaEquips;
        }
    }
}
